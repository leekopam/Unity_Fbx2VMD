// Workbench evidence 렌더링의 순수 로직. DOM·fetch 없이 동작해 node:test로 검증한다.

export const IMAGE_EXTENSIONS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"]);
export const VIDEO_EXTENSIONS = new Set([".mp4", ".webm", ".mov"]);
export const LOG_EXTENSIONS = new Set([".log", ".txt", ".md"]);

export function getArtifactFileName(artifactPath) {
  const parts = String(artifactPath ?? "").split("/");
  return parts.length === 2 && parts[0] === "artifacts" ? parts[1] : "";
}

export function getArtifactExtension(name) {
  const index = String(name).lastIndexOf(".");
  return index < 0 ? "" : String(name).slice(index).toLowerCase();
}

export function listArtifactsByExtension(artifacts, extensions) {
  return (artifacts ?? [])
    .map((artifact) => ({ artifact, name: getArtifactFileName(artifact.path) }))
    .filter(({ name }) => name !== "" && extensions.has(getArtifactExtension(name)))
    .map(({ artifact, name }) => ({ name, kind: artifact.kind, sizeBytes: artifact.sizeBytes }));
}

// 시간축 로그로 쓸 artifact를 고른다. kind가 log인 항목을 우선한다.
export function pickTimelineLogArtifact(artifacts) {
  const list = artifacts ?? [];
  const byKind = list.find((artifact) => artifact.kind === "log");
  if (byKind) {
    return getArtifactFileName(byKind.path);
  }
  const byExtension = listArtifactsByExtension(list, LOG_EXTENSIONS)[0];
  return byExtension ? byExtension.name : "";
}

const OFFSET_PATTERN = /\[\s*\+\s*(\d+(?:\.\d+)?)\s*s?\s*\]/;
const ISO_PATTERN = /(\d{4}-\d{2}-\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:[.,](\d{1,3}))?/;
const CLOCK_PATTERN = /(?:^|[^\d])(\d{1,2}):(\d{2}):(\d{2})(?:[.,](\d{1,3}))?/;

// 로그 한 줄에서 시각을 읽는다. 상대 시각([+초]), ISO, 시:분:초 세 형식을 지원한다.
export function parseLogTimestamp(line) {
  const offset = String(line).match(OFFSET_PATTERN);
  if (offset) {
    return { atMs: Math.round(Number(offset[1]) * 1000), type: "offset" };
  }
  const iso = String(line).match(ISO_PATTERN);
  if (iso) {
    const atMs = Date.parse(`${iso[1]}T${iso[2]}:${iso[3]}:${iso[4]}${iso[5] ? `.${iso[5].padEnd(3, "0")}` : ""}`);
    return Number.isNaN(atMs) ? undefined : { atMs, type: "absolute" };
  }
  const clock = String(line).match(CLOCK_PATTERN);
  if (clock) {
    const atMs = ((Number(clock[1]) * 60 + Number(clock[2])) * 60 + Number(clock[3])) * 1000
      + Number((clock[4] ?? "0").padEnd(3, "0"));
    return { atMs, type: "clock" };
  }
  return undefined;
}

// 첫 번째 시각 형식과 다른 형식의 줄은 섞이지 않게 걸러 시간축이 뒤틀리지 않게 한다.
export function extractTimelineEntries(text, { maxEntries = 500 } = {}) {
  const entries = [];
  let type = "";
  for (const rawLine of String(text ?? "").split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) {
      continue;
    }
    const parsed = parseLogTimestamp(line);
    if (!parsed) {
      continue;
    }
    if (!type) {
      type = parsed.type;
    }
    if (parsed.type !== type) {
      continue;
    }
    entries.push({ atMs: parsed.atMs, text: line });
    if (entries.length >= maxEntries) {
      break;
    }
  }
  return { entries, type };
}

export function buildTimeline(entries) {
  if (!entries || entries.length < 2) {
    return null;
  }
  const startMs = entries[0].atMs;
  const endMs = entries[entries.length - 1].atMs;
  const spanMs = endMs - startMs;
  if (!(spanMs > 0)) {
    return null;
  }
  return {
    startMs,
    endMs,
    spanMs,
    items: entries.map((entry) => ({
      ratio: (entry.atMs - startMs) / spanMs,
      atMs: entry.atMs,
      text: entry.text
    }))
  };
}

// Expected/Actual 픽셀 차이를 계산한다. 채널 차이 합계가 threshold를 넘으면 다른 픽셀로 본다.
// 반환 data는 diff 이미지의 RGBA 버퍼(같은 픽셀은 기준 회색조, 다른 픽셀은 빨간색).
export function computeImageDiff(expected, actual, width, height, { threshold = 96 } = {}) {
  const totalPixels = width * height;
  if (expected.length !== actual.length || expected.length !== totalPixels * 4) {
    throw new Error("비교할 두 이미지의 크기가 서로 다름");
  }
  const data = new Uint8ClampedArray(expected.length);
  let diffPixels = 0;
  for (let index = 0; index < expected.length; index += 4) {
    const delta = Math.abs(expected[index] - actual[index])
      + Math.abs(expected[index + 1] - actual[index + 1])
      + Math.abs(expected[index + 2] - actual[index + 2]);
    if (delta > threshold) {
      diffPixels += 1;
      data[index] = 255;
      data[index + 1] = 32;
      data[index + 2] = 32;
      data[index + 3] = 255;
      continue;
    }
    const gray = Math.round(expected[index] * 0.299 + expected[index + 1] * 0.587 + expected[index + 2] * 0.114);
    data[index] = gray;
    data[index + 1] = gray;
    data[index + 2] = gray;
    data[index + 3] = 255;
  }
  return {
    diffPixels,
    totalPixels,
    diffRatio: totalPixels > 0 ? diffPixels / totalPixels : 0,
    data
  };
}
