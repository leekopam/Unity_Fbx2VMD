"use strict";

// Boogle Workbench 클라이언트. 서버가 같은 출처에서 API와 정적 파일을 함께 제공한다.
// GUI는 조회·실행 요청·비교·승인 요청만 하고 판정·파일 변경은 Core가 수행한다.

const STATUS_LABEL = {
  PASS: "통과",
  FAIL: "실패",
  FLAKY: "불안정 통과",
  SKIP: "건너뜀",
  BLOCKED: "차단",
  TIMED_OUT: "시간 초과",
  INFRA_ERROR: "환경 오류",
  NOT_COMPARABLE: "비교 불가",
  MANUAL_REVIEW_REQUIRED: "수동 확인 필요",
  CANCELLED: "취소됨",
};

const PHASE_LABEL = {
  prepared: "실행 준비 완료",
  executing: "테스트 실행 중",
  sealing: "결과 봉인 중",
};

const state = {
  projects: [],
  projectId: "",
  runs: [],
  selectedRunId: "",
  detail: null,
  pinned: new Set(),
  config: null,
  job: null,
  jobTimer: null,
  view: "run",
};

const $ = (selector) => document.querySelector(selector);

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[ch]));
}

function formatTime(ms) {
  return new Date(ms).toLocaleString("ko-KR", { hour12: false });
}

function formatDuration(ms) {
  if (ms < 0) return "-";
  if (ms < 1000) return `${ms}ms`;
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds}초`;
  return `${Math.floor(seconds / 60)}분 ${seconds % 60}초`;
}

function shortId(id) {
  return typeof id === "string" ? id.slice(0, 8) : "";
}

function setNotice(message, tone = "info") {
  const notice = $("#globalNotice");
  notice.dataset.tone = tone;
  notice.textContent = message;
  notice.hidden = !message;
}

function setConn(message, tone = "info") {
  const badge = $("#connStatus");
  badge.dataset.tone = tone;
  badge.textContent = message;
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: options.body ? { "Content-Type": "application/json" } : undefined,
    ...options,
  });
  const type = response.headers.get("Content-Type") ?? "";
  const payload = type.includes("json") ? await response.json() : await response.text();
  if (!response.ok) {
    const message = payload && payload.error ? payload.error.message : `요청 실패 (${response.status})`;
    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function statusBadge(status) {
  const label = STATUS_LABEL[status] ?? status;
  return `<span class="wb-badge" data-status="${escapeHtml(status)}">${escapeHtml(status)} ${escapeHtml(label)}</span>`;
}

// ---- 뷰 전환 ----

function selectView(view) {
  state.view = view;
  for (const button of document.querySelectorAll(".wb-nav-button")) {
    const active = button.dataset.view === view;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  }
  for (const panel of document.querySelectorAll(".wb-panel")) {
    panel.hidden = panel.dataset.panel !== view;
  }
  if (view === "history") void refreshRuns();
  if (view === "compare") void refreshCompareInputs();
  if (view === "retention") void refreshRetention();
}

// ---- 프로젝트 ----

async function refreshProjects() {
  setConn("불러오는 중…", "info");
  try {
    const { projects } = await api("/api/projects");
    state.projects = projects;
    const select = $("#projectSelect");
    select.innerHTML = "";
    if (projects.length === 0) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "기록된 프로젝트 없음";
      select.append(option);
      state.projectId = "";
    } else {
      for (const pid of projects) {
        const option = document.createElement("option");
        option.value = pid;
        option.textContent = pid;
        select.append(option);
      }
      if (!projects.includes(state.projectId)) state.projectId = projects[0];
      select.value = state.projectId;
    }
    setConn(`연결됨 · 프로젝트 ${projects.length}개`, "success");
    updateExportLinks();
    state.runs = [];
    state.selectedRunId = "";
    state.detail = null;
    if (state.view === "history") await refreshRuns();
    if (state.view === "compare") await refreshCompareInputs();
  } catch (error) {
    setConn(`연결 실패: ${error.message}`, "error");
  }
}

function requireProject() {
  if (!state.projectId) {
    setNotice("기록이 있는 프로젝트가 없습니다. 먼저 `boogle run`으로 실행을 만드세요.", "error");
    return false;
  }
  return true;
}

// ---- 실행 기록 ----

async function refreshRuns() {
  if (!requireProject()) return;
  const body = $("#runListBody");
  body.innerHTML = "<tr><td colspan='5'>불러오는 중…</td></tr>";
  try {
    const [{ runs }, baselinesData] = await Promise.all([
      api(`/api/runs?projectId=${state.projectId}`),
      api(`/api/baselines?projectId=${state.projectId}`).catch(() => ({ baselines: [] })),
    ]);
    state.runs = runs;
    state.pinned = new Set();
    $("#runListEmpty").hidden = runs.length > 0;
    body.innerHTML = "";
    for (const run of runs) {
      const tr = document.createElement("tr");
      tr.tabIndex = 0;
      tr.dataset.runId = run.runId;
      tr.innerHTML = `<td>${statusBadge(run.status)}</td>
        <td>${escapeHtml(formatTime(run.startedAtMs))}</td>
        <td>${escapeHtml(formatDuration(run.finishedAtMs - run.startedAtMs))}</td>
        <td><code>${escapeHtml(run.runId)}</code></td>
        <td class="wb-pin-cell" data-pin-cell>—</td>`;
      tr.addEventListener("click", () => void openRunDetail(run.runId));
      tr.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          void openRunDetail(run.runId);
        }
      });
      body.append(tr);
    }
    for (const baseline of baselinesData.baselines) {
      for (const tr of body.querySelectorAll("tr")) {
        if (tr.dataset.runId === baseline.runId) {
          tr.querySelector("[data-pin-cell]").textContent = `기준선: ${baseline.baselineId} r${baseline.revision}`;
        }
      }
    }
    if (state.selectedRunId && !state.detail) {
      void openRunDetail(state.selectedRunId);
    }
  } catch (error) {
    body.innerHTML = "";
    $("#runListEmpty").hidden = false;
    $("#runListEmpty").textContent = `실행 기록을 불러오지 못했습니다: ${error.message}`;
  }
}

async function openRunDetail(runId) {
  if (!requireProject()) return;
  state.selectedRunId = runId;
  const box = $("#runDetail");
  box.hidden = false;
  box.innerHTML = "<p>실행 상세를 불러오는 중…</p>";
  for (const tr of $("#runListBody").querySelectorAll("tr")) {
    tr.classList.toggle("selected", tr.dataset.runId === runId);
  }
  try {
    const [detail, analysis] = await Promise.all([
      api(`/api/runs/${state.projectId}/${runId}`),
      api(`/api/runs/${state.projectId}/${runId}/analysis`).catch(() => null),
    ]);
    state.detail = detail;
    renderRunDetail(detail, analysis);
  } catch (error) {
    box.innerHTML = `<p class="wb-error">상세를 불러오지 못했습니다: ${escapeHtml(error.message)}</p>`;
  }
}

function renderRunDetail(detail, analysis) {
  const { manifest, result, index, bundle, retention, pin } = detail;
  const box = $("#runDetail");
  const conditions = (record) => Object.entries(record)
    .map(([key, value]) => `<tr><td>${escapeHtml(key)}</td><td><code>${escapeHtml(String(value).slice(0, 19))}…</code></td></tr>`)
    .join("");

  const metricsRows = (bundle?.metrics ?? []).map((metric) => `
    <tr><td><code>${escapeHtml(metric.name)}</code></td><td>${metric.value}</td><td>${escapeHtml(metric.unit)}</td>
    <td>${escapeHtml(metric.direction === "lower" ? "낮을수록" : "높을수록")}</td>
    <td>${escapeHtml(metric.threshold.kind)} ${escapeHtml(String(metric.threshold.value))}</td></tr>`).join("");

  const artifactRows = index.artifacts.map((artifact, i) => {
    const name = artifact.path.split("/")[1];
    return `<tr><td><code>${escapeHtml(artifact.kind)}</code></td>
      <td>${escapeHtml((artifact.sizeBytes / 1024).toFixed(1))}KB</td>
      <td><button type="button" class="wb-link" data-artifact="${escapeHtml(name)}">${escapeHtml(name.slice(0, 20))}…</button></td></tr>`;
  }).join("");

  box.innerHTML = `
    <div class="wb-card">
      <div class="wb-detail-head">
        <h3>실행 상세</h3>${statusBadge(result.status)}
      </div>
      <table class="wb-table wb-kv">
        <tr><td>실행 ID</td><td><code>${escapeHtml(result.runId)}</code></td></tr>
        <tr><td>Adapter</td><td>${escapeHtml(manifest.adapter.id)} ${escapeHtml(manifest.adapter.version)}</td></tr>
        <tr><td>Test Pack</td><td>${escapeHtml(manifest.testPack.id)} ${escapeHtml(manifest.testPack.version)}</td></tr>
        <tr><td>시작</td><td>${escapeHtml(formatTime(manifest.startedAtMs))}</td></tr>
        <tr><td>종료</td><td>${escapeHtml(formatTime(result.finishedAtMs))} (${escapeHtml(formatDuration(result.finishedAtMs - manifest.startedAtMs))})</td></tr>
        ${result.exitCode !== undefined ? `<tr><td>종료 코드</td><td>${result.exitCode}</td></tr>` : ""}
        ${result.failureKind ? `<tr><td>실패 분류</td><td>${escapeHtml(result.failureKind)}${result.failureCode ? ` / ${escapeHtml(result.failureCode)}` : ""}</td></tr>` : ""}
        ${result.testSummary ? `<tr><td>테스트</td><td>총 ${result.testSummary.total}, 통과 ${result.testSummary.passed}, 실패 ${result.testSummary.failed}, 미결 ${result.testSummary.inconclusive}, 건너뜀 ${result.testSummary.skipped}</td></tr>` : ""}
        ${result.retry ? `<tr><td>재시도</td><td>${result.retry.attemptNumber}/${result.retry.maxRetries + 1}번째 시도${result.retry.firstFailureRunId ? `, 첫 실패 <code>${escapeHtml(result.retry.firstFailureRunId)}</code>` : ""}</td></tr>` : ""}
        ${retention ? `<tr><td>보존 기록</td><td>만료 evidence ${retention.artifacts.length}개 정리됨 (${escapeHtml(formatTime(retention.markedAtMs))})</td></tr>` : ""}
        ${pin ? `<tr><td>pin</td><td>${escapeHtml(formatTime(pin.pinnedAtMs))} — ${escapeHtml(pin.reason)}</td></tr>` : ""}
      </table>
      ${analysis && analysis.nextChecks.length ? `<div class="wb-next"><strong>다음 확인:</strong><ul>${analysis.nextChecks.map((c) => `<li>${escapeHtml(c)}</li>`).join("")}</ul></div>` : ""}

      <details><summary>입력·환경 조건(해시)</summary>
        <table class="wb-table wb-kv">${conditions(manifest.inputConditions)}${conditions(manifest.environmentConditions)}</table>
      </details>

      ${metricsRows ? `<h4>metric</h4>
        <table class="wb-table"><thead><tr><th>이름</th><th>값</th><th>단위</th><th>방향</th><th>임계</th></tr></thead><tbody>${metricsRows}</tbody></table>` : "<p class='wb-empty'>기록된 metric이 없습니다.</p>"}

      ${artifactRows ? `<h4>evidence</h4>
        <table class="wb-table"><thead><tr><th>종류</th><th>크기</th><th>파일</th></tr></thead><tbody>${artifactRows}</tbody></table>
        <div id="artifactViewer" class="wb-artifact-viewer" hidden></div>` : "<p class='wb-empty'>evidence가 없습니다.</p>"}

      <details><summary>고정 보고서</summary><pre id="reportPre" class="wb-pre">불러오는 중…</pre></details>
      ${analysis ? `<details><summary>분석 입력</summary><pre class="wb-pre">${escapeHtml(JSON.stringify(analysis, null, 2))}</pre></details>` : ""}

      <div class="wb-actions">
        <div class="wb-row">
          <input id="pinReason" type="text" placeholder="pin 사유" aria-label="pin 사유" />
          <button id="pinButton" type="button" ${pin ? "disabled" : ""}>pin 고정</button>
          <button id="unpinButton" type="button" ${pin ? "" : "disabled"}>pin 해제</button>
        </div>
        <div class="wb-row">
          <input id="baselineIdInput" type="text" placeholder="기준선 이름" aria-label="기준선 이름" />
          <input id="baselineReasonInput" type="text" class="wb-input-grow" placeholder="승인 사유" aria-label="승인 사유" />
          <button id="baselineApproveButton" type="button" ${result.status === "PASS" && bundle ? "" : "disabled"}>기준선 승인</button>
        </div>
      </div>
    </div>`;

  for (const button of box.querySelectorAll("[data-artifact]")) {
    button.addEventListener("click", () => void showArtifact(detail, button.dataset.artifact));
  }
  void loadReport();
  wireDetailActions(detail);
}

async function showArtifact(detail, name) {
  const viewer = $("#artifactViewer");
  viewer.hidden = false;
  viewer.innerHTML = "<p>evidence를 불러오는 중…</p>";
  const url = `/api/artifacts/${state.projectId}/${detail.result.runId}/${name}`;
  const ext = name.includes(".") ? name.slice(name.lastIndexOf(".")) : "";
  try {
    if ([".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"].includes(ext)) {
      viewer.innerHTML = `<img src="${url}" alt="실행 evidence 이미지" class="wb-artifact-image" />`;
      return;
    }
    if ([".mp4", ".webm", ".mov"].includes(ext)) {
      viewer.innerHTML = `<video src="${url}" controls class="wb-artifact-video"></video>`;
      return;
    }
    if ([".txt", ".log", ".md", ".json", ".xml", ".csv"].includes(ext)) {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`불러오기 실패 (${response.status})`);
      viewer.innerHTML = `<pre class="wb-pre wb-artifact-text">${escapeHtml(await response.text())}</pre>`;
      return;
    }
    viewer.innerHTML = `<a class="wb-link-button" href="${url}" download>파일 내려받기</a>`;
  } catch (error) {
    viewer.innerHTML = `<p class="wb-error">evidence를 열지 못했습니다: ${escapeHtml(error.message)}</p>`;
  }
}

async function loadReport() {
  const pre = $("#reportPre");
  if (!pre) return;
  try {
    const { report } = await api(`/api/runs/${state.projectId}/${state.selectedRunId}/report`);
    pre.textContent = report;
  } catch (error) {
    pre.textContent = `보고서를 불러오지 못했습니다: ${error.message}`;
  }
}

function wireDetailActions(detail) {
  const pinButton = $("#pinButton");
  const unpinButton = $("#unpinButton");
  const approveButton = $("#baselineApproveButton");
  pinButton?.addEventListener("click", async () => {
    const reason = $("#pinReason").value.trim();
    if (reason.length < 3) {
      setNotice("pin 사유를 3자 이상 입력하세요.", "error");
      return;
    }
    pinButton.disabled = true;
    try {
      await api(`/api/runs/${state.projectId}/${state.selectedRunId}/pin`, {
        method: "POST", body: JSON.stringify({ reason }),
      });
      setNotice("실행을 pin으로 고정했습니다.", "success");
      void openRunDetail(state.selectedRunId);
    } catch (error) {
      pinButton.disabled = false;
      setNotice(`pin 실패: ${error.message}`, "error");
    }
  });
  unpinButton?.addEventListener("click", async () => {
    if (!globalThis.confirm("pin을 해제하면 보존 정리 대상이 될 수 있습니다. 해제할까요?")) return;
    unpinButton.disabled = true;
    try {
      await api(`/api/runs/${state.projectId}/${state.selectedRunId}/unpin`, {
        method: "POST", body: JSON.stringify({ confirm: true }),
      });
      setNotice("pin을 해제했습니다.", "success");
      void openRunDetail(state.selectedRunId);
    } catch (error) {
      unpinButton.disabled = false;
      setNotice(`pin 해제 실패: ${error.message}`, "error");
    }
  });
  approveButton?.addEventListener("click", async () => {
    const baselineId = $("#baselineIdInput").value.trim();
    const reason = $("#baselineReasonInput").value.trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(baselineId)) {
      setNotice("기준선 이름은 영문·숫자·_- 로 시작하는 1~64자여야 합니다.", "error");
      return;
    }
    if (reason.length < 3) {
      setNotice("승인 사유를 3자 이상 입력하세요.", "error");
      return;
    }
    if (!globalThis.confirm(`실행 ${shortId(detail.result.runId)}을(를) 기준선 "${baselineId}"으로 승인합니다. 계속할까요?`)) return;
    approveButton.disabled = true;
    try {
      const approval = await api("/api/baseline-approve", {
        method: "POST",
        body: JSON.stringify({
          projectId: state.projectId, baselineId, runId: state.selectedRunId, reason, confirm: true,
        }),
      });
      setNotice(`기준선 "${baselineId}" 버전 ${approval.revision}을(를) 승인했습니다.`, "success");
    } catch (error) {
      approveButton.disabled = false;
      setNotice(`기준선 승인 실패: ${error.message}`, "error");
    }
  });
}

// ---- 새 실행 ----

async function loadConfig() {
  const path = $("#configPathInput").value.trim();
  if (!path) {
    setNotice("설정 파일 경로를 입력하세요.", "error");
    return;
  }
  const button = $("#loadConfigButton");
  button.disabled = true;
  setNotice("설정 파일을 읽는 중…", "info");
  try {
    const { config } = await api("/api/config-preview", {
      method: "POST", body: JSON.stringify({ path }),
    });
    state.config = config;
    renderConfigPreview(config);
    $("#startRunButton").disabled = false;
    setNotice("설정을 불러왔습니다. 내용을 확인한 뒤 실행하세요.", "success");
  } catch (error) {
    state.config = null;
    $("#startRunButton").disabled = true;
    $("#configPreview").hidden = true;
    setNotice(`설정 불러오기 실패: ${error.message}`, "error");
  } finally {
    button.disabled = false;
  }
}

function renderConfigPreview(config) {
  const preview = $("#configPreview");
  preview.hidden = false;
  const summary = [
    `- Adapter: ${config?.adapter?.id ?? "?"} ${config?.adapter?.version ?? ""}`,
    `- Test Pack: ${config?.testPack?.id ?? "?"} ${config?.testPack?.version ?? ""}`,
    `- 프로젝트: ${config?.projectId ?? "?"}`,
    `- 재시도: ${config?.retries ?? 0}회`,
    config?.command ? `- 명령: ${config.command.executable}` : "",
    config?.unity ? `- Unity: ${config.unity.testPlatform}, 제한 ${Math.round((config.unity.timeoutMs ?? 0) / 60000)}분` : "",
  ].filter(Boolean).join("\n");
  preview.innerHTML = `<pre class="wb-pre">${escapeHtml(summary)}\n\n${escapeHtml(JSON.stringify(config, null, 2))}</pre>`;
}

async function startRun() {
  if (!state.config) return;
  const button = $("#startRunButton");
  button.disabled = true;
  try {
    const { jobId } = await api("/api/runs", {
      method: "POST", body: JSON.stringify({ config: state.config }),
    });
    setNotice("실행을 시작했습니다.", "success");
    $("#jobMonitor").hidden = false;
    $("#jobResult").hidden = true;
    $("#jobEvents").innerHTML = "";
    $("#cancelJobButton").hidden = false;
    pollJob(jobId);
  } catch (error) {
    button.disabled = false;
    setNotice(`실행 시작 실패: ${error.message}`, "error");
  }
}

async function pollJob(jobId) {
  clearInterval(state.jobTimer);
  const update = async () => {
    try {
      const job = await api(`/api/jobs/${jobId}`);
      state.job = job;
      renderJob(job);
      if (job.state !== "running") {
        clearInterval(state.jobTimer);
        state.jobTimer = null;
        $("#cancelJobButton").hidden = true;
        $("#startRunButton").disabled = false;
        renderJobResult(job);
        state.runs = [];
      }
    } catch (error) {
      clearInterval(state.jobTimer);
      setNotice(`실행 상태 확인 실패: ${error.message}`, "error");
      $("#cancelJobButton").hidden = true;
      $("#startRunButton").disabled = false;
    }
  };
  await update();
  if (state.job?.state === "running") {
    state.jobTimer = setInterval(() => void update(), 800);
  }
}

function renderJob(job) {
  const statusBox = $("#jobStatus");
  const elapsed = formatDuration((job.finishedAtMs ?? Date.now()) - job.startedAtMs);
  const stateLabel = job.state === "running"
    ? (job.cancelRequested ? "취소 요청됨 · 안전 정리 중" : "실행 중")
    : job.state === "finished" ? "완료" : "오류";
  statusBox.innerHTML = `<p><strong>${escapeHtml(stateLabel)}</strong> · 경과 ${escapeHtml(elapsed)} · adapter ${escapeHtml(job.adapterId)}</p>`;
  const events = $("#jobEvents");
  events.innerHTML = job.events.map((event) =>
    `<li>${escapeHtml(formatTime(event.atMs))} — ${escapeHtml(PHASE_LABEL[event.phase] ?? event.phase)} (시도 ${event.attemptNumber}, 실행 <code>${escapeHtml(shortId(event.runId))}</code>)</li>`,
  ).join("");
}

function renderJobResult(job) {
  const box = $("#jobResult");
  box.hidden = false;
  if (job.state === "error") {
    box.innerHTML = `<p class="wb-error">실행이 오류로 끝났습니다: ${escapeHtml(job.error ?? "")}</p>`;
    return;
  }
  const summary = job.summary;
  if (!summary) {
    box.innerHTML = `<p class="wb-error">실행 요약이 없습니다.</p>`;
    return;
  }
  box.innerHTML = `
    <p>${statusBadge(summary.status)} · 실행 <code>${escapeHtml(summary.runId)}</code></p>
    ${summary.testSummary ? `<p>테스트: 총 ${summary.testSummary.total}, 통과 ${summary.testSummary.passed}, 실패 ${summary.testSummary.failed}</p>` : ""}
    ${summary.failureKind ? `<p>실패 분류: ${escapeHtml(summary.failureKind)}${summary.failureCode ? ` / ${escapeHtml(summary.failureCode)}` : ""}</p>` : ""}
    ${summary.attemptRunIds?.length > 1 ? `<p>시도: ${summary.attemptRunIds.map((id) => `<code>${escapeHtml(shortId(id))}</code>`).join(" → ")}</p>` : ""}
    <p><button type="button" id="openDetailAfterRun" class="wb-link">실행 상세 열기</button></p>`;
  $("#openDetailAfterRun")?.addEventListener("click", () => {
    state.projectId = summary.projectId;
    $("#projectSelect").value = summary.projectId;
    state.selectedRunId = summary.runId;
    state.detail = null;
    selectView("history");
    void openRunDetail(summary.runId);
  });
}

async function cancelJob() {
  const job = state.job;
  if (!job || job.state !== "running") return;
  const button = $("#cancelJobButton");
  button.disabled = true;
  try {
    await api(`/api/jobs/${job.jobId}/cancel`, { method: "POST" });
    setNotice("취소를 요청했습니다. 정리가 끝날 때까지 기다리세요.", "info");
  } catch (error) {
    setNotice(`취소 실패: ${error.message}`, "error");
    button.disabled = false;
  }
}

// ---- 비교 ----

async function refreshCompareInputs() {
  if (!requireProject()) return;
  if (state.runs.length === 0) {
    try {
      const { runs } = await api(`/api/runs?projectId=${state.projectId}`);
      state.runs = runs;
    } catch (error) {
      setNotice(`실행 목록을 불러오지 못했습니다: ${error.message}`, "error");
      return;
    }
  }
  const options = state.runs.map((run) =>
    `<option value="${escapeHtml(run.runId)}">${escapeHtml(formatTime(run.startedAtMs))} · ${escapeHtml(run.status)} · ${escapeHtml(shortId(run.runId))}</option>`,
  ).join("");
  $("#compareReference").innerHTML = options;
  $("#compareCurrent").innerHTML = options;
  if (state.runs.length >= 2) {
    $("#compareReference").value = state.runs[1].runId;
    $("#compareCurrent").value = state.runs[0].runId;
  }
  await fillMetricNames();
  await refreshBaselines();
}

async function fillMetricNames() {
  const current = $("#compareCurrent").value;
  const datalist = $("#metricNames");
  datalist.innerHTML = "";
  if (!current) return;
  try {
    const detail = await api(`/api/runs/${state.projectId}/${current}`);
    for (const metric of detail.bundle?.metrics ?? []) {
      const option = document.createElement("option");
      option.value = metric.name;
      datalist.append(option);
    }
  } catch {
    // metric 후보 목록은 보조 기능이므로 실패해도 입력은 가능하게 둔다.
  }
}

async function runCompare() {
  const name = $("#compareMetric").value.trim();
  const reference = $("#compareReference").value;
  const current = $("#compareCurrent").value;
  const box = $("#compareResult");
  if (!reference || !current || !name) {
    setNotice("기준 실행, 현재 실행, metric 이름을 모두 선택하세요.", "error");
    return;
  }
  box.hidden = false;
  box.innerHTML = "<p>비교하는 중…</p>";
  try {
    const comparison = await api(
      `/api/compare?projectId=${state.projectId}&reference=${reference}&current=${current}&name=${encodeURIComponent(name)}`,
    );
    renderComparison(comparison, box);
    await renderTrend(name);
  } catch (error) {
    box.innerHTML = `<p class="wb-error">비교 실패: ${escapeHtml(error.message)}</p>`;
  }
}

function renderComparison(comparison, box) {
  if (comparison.status === "NOT_COMPARABLE") {
    box.innerHTML = `<p>${statusBadge("NOT_COMPARABLE")} 비교 불가: <code>${escapeHtml(comparison.reason)}</code></p>`;
    return;
  }
  const deltaText = `${comparison.delta >= 0 ? "+" : ""}${comparison.delta} ${escapeHtml(comparison.unit)}` +
    (comparison.relativePercent !== undefined ? ` (${comparison.relativePercent.toFixed(2)}%)` : "");
  box.innerHTML = `
    <p>${statusBadge(comparison.status)}</p>
    <table class="wb-table wb-kv">
      <tr><td>기준값</td><td>${comparison.referenceValue} ${escapeHtml(comparison.unit)} (실행 ${escapeHtml(comparison.referenceStatus)})</td></tr>
      <tr><td>현재값</td><td>${comparison.currentValue} ${escapeHtml(comparison.unit)} (실행 ${escapeHtml(comparison.currentStatus)})</td></tr>
      <tr><td>차이</td><td>${deltaText}</td></tr>
      <tr><td>임계</td><td>${escapeHtml(comparison.threshold.kind)} ${comparison.threshold.value}</td></tr>
    </table>`;
}

async function renderTrend(name) {
  const box = $("#trendChart");
  try {
    const { trend } = await api(`/api/trend?projectId=${state.projectId}&name=${encodeURIComponent(name)}`);
    if (!trend.length) {
      box.hidden = true;
      return;
    }
    box.hidden = false;
    const values = trend.map((point) => point.value);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const span = max - min || 1;
    const width = 560;
    const height = 120;
    const points = trend.map((point, i) => {
      const x = 24 + (i / Math.max(trend.length - 1, 1)) * (width - 48);
      const y = height - 20 - ((point.value - min) / span) * (height - 40);
      return `${x},${y}`;
    });
    box.innerHTML = `
      <h4>metric 추세 (${escapeHtml(name)})</h4>
      <svg viewBox="0 0 ${width} ${height}" class="wb-trend" role="img" aria-label="metric 추세 그래프">
        <polyline points="${points.join(" ")}" fill="none" stroke="#2563eb" stroke-width="2" />
        ${trend.map((point, i) => {
          const [x, y] = points[i].split(",");
          return `<circle cx="${x}" cy="${y}" r="3" fill="${point.status === "PASS" ? "#2563eb" : "#dc2626"}"><title>${escapeHtml(formatTime(point.startedAtMs))} ${point.value}${escapeHtml(point.unit)} ${escapeHtml(point.status)}</title></circle>`;
        }).join("")}
      </svg>
      <p class="wb-help">최근 ${trend.length}개 실행 · 범위 ${min}~${max} ${escapeHtml(trend[0].unit)}</p>`;
  } catch {
    box.hidden = true;
  }
}

async function refreshBaselines() {
  if (!state.projectId) return;
  const body = $("#baselineBody");
  try {
    const { baselines } = await api(`/api/baselines?projectId=${state.projectId}`);
    $("#baselineEmpty").hidden = baselines.length > 0;
    body.innerHTML = baselines.map((baseline) => `
      <tr><td>${escapeHtml(baseline.baselineId)}</td><td>r${baseline.revision}</td>
      <td><code>${escapeHtml(shortId(baseline.runId))}</code></td>
      <td>${escapeHtml(formatTime(baseline.approvedAtMs))}</td>
      <td>${escapeHtml(baseline.reason)}</td>
      <td><button type="button" class="wb-link" data-baseline-compare="${escapeHtml(baseline.baselineId)}">선택 실행과 비교</button></td></tr>`,
    ).join("");
    for (const button of body.querySelectorAll("[data-baseline-compare]")) {
      button.addEventListener("click", () => void runBaselineCompare(button.dataset.baselineCompare));
    }
  } catch (error) {
    body.innerHTML = "";
    $("#baselineEmpty").hidden = false;
    $("#baselineEmpty").textContent = `기준선 목록을 불러오지 못했습니다: ${error.message}`;
  }
}

async function runBaselineCompare(baselineId) {
  const current = $("#compareCurrent").value;
  const name = $("#compareMetric").value.trim();
  const box = $("#baselineCompareResult");
  if (!current || !name) {
    setNotice("비교할 현재 실행과 metric 이름을 먼저 선택하세요.", "error");
    return;
  }
  box.hidden = false;
  box.innerHTML = "<p>기준선과 비교하는 중…</p>";
  try {
    const comparison = await api(
      `/api/baseline-compare?projectId=${state.projectId}&baselineId=${encodeURIComponent(baselineId)}&runId=${current}&name=${encodeURIComponent(name)}`,
    );
    renderComparison(comparison, box);
  } catch (error) {
    box.innerHTML = `<p class="wb-error">기준선 비교 실패: ${escapeHtml(error.message)}</p>`;
  }
}

// ---- 보관·보내기 ----

async function refreshRetention() {
  updateExportLinks();
}

function updateExportLinks() {
  if (!state.projectId) return;
  $("#exportJson").href = `/api/export?projectId=${state.projectId}&format=json`;
  $("#exportCsv").href = `/api/export?projectId=${state.projectId}&format=csv`;
}

async function previewCleanup() {
  if (!requireProject()) return;
  const box = $("#cleanupResult");
  box.hidden = false;
  box.innerHTML = "<p>정리 대상을 계산하는 중…</p>";
  try {
    const result = await api("/api/cleanup", {
      method: "POST", body: JSON.stringify({ projectId: state.projectId, confirm: false }),
    });
    if (result.eligible.length === 0) {
      box.innerHTML = "<p>정리 대상이 없습니다.</p>";
      $("#cleanupRunButton").disabled = true;
      return;
    }
    const totalKb = result.eligible.reduce((sum, item) => sum + item.sizeBytes, 0) / 1024;
    box.innerHTML = `
      <p>정리 대상 ${result.eligible.length}개 파일 · ${totalKb.toFixed(1)}KB</p>
      <ul>${result.eligible.slice(0, 50).map((item) =>
        `<li><code>${escapeHtml(shortId(item.runId))}</code> ${escapeHtml(item.path)} (${(item.sizeBytes / 1024).toFixed(1)}KB)</li>`).join("")}
        ${result.eligible.length > 50 ? `<li>… 외 ${result.eligible.length - 50}개</li>` : ""}</ul>`;
    $("#cleanupRunButton").disabled = false;
  } catch (error) {
    box.innerHTML = `<p class="wb-error">미리보기 실패: ${escapeHtml(error.message)}</p>`;
  }
}

async function runCleanup() {
  if (!globalThis.confirm("만료된 evidence 파일을 삭제합니다. 되돌릴 수 없습니다. 계속할까요?")) return;
  const box = $("#cleanupResult");
  const button = $("#cleanupRunButton");
  button.disabled = true;
  try {
    const result = await api("/api/cleanup", {
      method: "POST", body: JSON.stringify({ projectId: state.projectId, confirm: true }),
    });
    box.innerHTML = `<p>${result.removed}개 파일을 정리했습니다.</p>`;
    setNotice("보존 정리를 완료했습니다.", "success");
  } catch (error) {
    box.innerHTML = `<p class="wb-error">정리 실패: ${escapeHtml(error.message)}</p>`;
    button.disabled = false;
  }
}

// ---- 시작 ----

function bootstrap() {
  for (const button of document.querySelectorAll(".wb-nav-button")) {
    button.addEventListener("click", () => selectView(button.dataset.view));
  }
  $("#projectSelect").addEventListener("change", (event) => {
    state.projectId = event.target.value;
    state.runs = [];
    state.selectedRunId = "";
    state.detail = null;
    $("#runDetail").hidden = true;
    updateExportLinks();
    if (state.view === "history") void refreshRuns();
    if (state.view === "compare") void refreshCompareInputs();
  });
  $("#refreshProjects").addEventListener("click", () => void refreshProjects());
  $("#loadConfigButton").addEventListener("click", () => void loadConfig());
  $("#startRunButton").addEventListener("click", () => void startRun());
  $("#cancelJobButton").addEventListener("click", () => void cancelJob());
  $("#compareButton").addEventListener("click", () => void runCompare());
  $("#compareCurrent").addEventListener("change", () => void fillMetricNames());
  $("#cleanupPreviewButton").addEventListener("click", () => void previewCleanup());
  $("#cleanupRunButton").addEventListener("click", () => void runCleanup());
  selectView("run");
  void refreshProjects();
}

if (typeof document !== "undefined") {
  bootstrap();
}
