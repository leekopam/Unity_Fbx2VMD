# Boogle

여러 프로젝트에서 재사용하는 로컬 E2E 테스트 SDK. 설정 검증, 임시 실행 봉인, SQLite Catalog, 일반 명령·Unity 테스트 Adapter, metric 추세·비교, 명시 승인 기준선, 실행 상세·JSON/CSV 내보내기와 보존 정리를 제공한다. 실제 Unity Editor smoke는 아직 검증되지 않았다.

## 개발 환경

- Windows
- Node.js 24
- npm

```powershell
npm ci
npm run check
npm run build
npm test
npm run verify
npm start
```

`npm start`는 CLI 도움말을 출력한다. SDK 개발 범위와 순서는 [개발 사양](docs/2026-09-22-Boogle-SDK-개발-사양.md)을 따른다.

`npm run verify`는 로컬에서 타입 검사·전체 테스트·패키지 목록 검사를 순서대로 실행한다. 현재 버전은 `0.1.0-beta.0`이고 `private: true`를 유지해 공개 Registry 게시를 차단한다. `npm run pack:check`는 파일 목록만 확인하며 tarball을 만들지 않는다. 실제 로컬 설치용 tarball이 필요할 때만 `npm pack --ignore-scripts`를 사용한다. 원격 CI나 자동 게시·배포는 구성하지 않았다.

## 일반 명령 실행

프로젝트별 JSON 설정을 만들고 실행한다. 아래 절대 경로는 실제 설치 경로로 바꿔야 한다. 실행 파일은 `.exe` 등 직접 실행 가능한 파일이어야 하며 `.bat`, `.cmd`, `.ps1`은 지원하지 않는다.

```json
{
  "protocolVersion": "0.1.0",
  "projectId": "e7a4f8cb-8e19-4e91-91dd-e92e068a8418",
  "adapter": { "id": "command", "version": "0.1.0" },
  "testPack": { "id": "example", "version": "0.1.0" },
  "command": {
    "executable": "C:\\path\\to\\node.exe",
    "args": ["--version"],
    "workingDirectory": "C:\\path\\to\\project",
    "timeoutMs": 10000
  },
  "inputConditions": { "fixture": "example-1" },
  "environmentConditions": { "platform": "windows" }
}
```

```powershell
node dist/cli.js run C:\path\to\test-pack.json
node dist/cli.js list e7a4f8cb-8e19-4e91-91dd-e92e068a8418
node dist/cli.js detail e7a4f8cb-8e19-4e91-91dd-e92e068a8418 <runId>
node dist/cli.js report e7a4f8cb-8e19-4e91-91dd-e92e068a8418 <runId>
node dist/cli.js analysis-input e7a4f8cb-8e19-4e91-91dd-e92e068a8418 <runId>
node dist/cli.js trend e7a4f8cb-8e19-4e91-91dd-e92e068a8418 artifact/bytes_per_frame
node dist/cli.js compare e7a4f8cb-8e19-4e91-91dd-e92e068a8418 <기준-runId> <현재-runId> artifact/bytes_per_frame
node dist/cli.js baseline-approve e7a4f8cb-8e19-4e91-91dd-e92e068a8418 smoke <기준-runId> "첫 검증 기준 승인" --confirm
node dist/cli.js baseline-compare e7a4f8cb-8e19-4e91-91dd-e92e068a8418 smoke <현재-runId> artifact/bytes_per_frame
node dist/cli.js pin e7a4f8cb-8e19-4e91-91dd-e92e068a8418 <runId> "후속 조사 근거 보관"
node dist/cli.js unpin e7a4f8cb-8e19-4e91-91dd-e92e068a8418 <runId> --confirm
node dist/cli.js cleanup e7a4f8cb-8e19-4e91-91dd-e92e068a8418
node dist/cli.js cleanup e7a4f8cb-8e19-4e91-91dd-e92e068a8418 --confirm
node dist/cli.js recover --confirm
node dist/cli.js export e7a4f8cb-8e19-4e91-91dd-e92e068a8418 json
node dist/cli.js export e7a4f8cb-8e19-4e91-91dd-e92e068a8418 csv
node dist/cli.js reindex
```

기본 데이터 루트는 `%LOCALAPPDATA%\Boogle`이다. 필요하면 각 명령에 `--data-root <절대 경로>`를 붙인다. `run`은 결과 상태와 봉인 경로를 JSON으로 출력한다. 종료 코드 0은 `PASS`, 1은 테스트 실패·차단·취소 등, 2는 설정 또는 CLI 오류다. 결과의 `failureKind`·`failureCode`는 원시 경로와 로그를 제외한 실패 분류다. 현재 명령의 stdout/stderr는 저장하지 않으므로 민감값이 포함된 원시 출력이 evidence에 남지 않는다.

설정 최상위에 `"retries": 1`을 넣으면 실패한 Test Pack 전체를 최대 1회 다시 실행한다. 기본값은 0회이고 허용 범위는 0~3회다. `FAIL`만 재시도하며 차단·시간 초과·인프라 오류·취소는 재시도하지 않는다. 각 시도는 별도 실행 ID와 봉인 근거를 가지며 CLI의 `attemptRunIds`에 순서대로 표시된다. 재시도 후 통과도 `FLAKY`와 종료 코드 1로 처리하고 첫 실패 근거를 보존한다. 재시도 예산이 다르면 metric 비교는 `NOT_COMPARABLE`이며, 현재 실행이 `PASS`가 아니면 수치가 임계값 안이어도 비교 결과는 `FAIL`이다.

`detail`은 해당 실행의 봉인된 manifest·result·metric·artifact index를 무결성 확인 후 출력한다. `export`는 Catalog가 찾은 실행의 같은 메타데이터를 JSON 또는 CSV로 표준 출력하며, 원시 artifact 내용은 포함하지 않는다. Catalog 누락이 의심되면 먼저 `reindex`를 실행한다. CSV의 수식 시작 문자열은 문자로 처리되도록 접두어를 붙인다. 저장이 필요하면 원하는 로컬 파일로 출력 방향을 지정한다.

`report`는 봉인된 단일 실행을 한국어 Markdown으로 요약한다. `analysis-input`은 같은 실행의 상태·실패 분류·테스트 수치·허용 형식의 metric 단위·artifact 수·다음 확인 항목만 JSON으로 출력한다. 두 명령 모두 원본 로그·Unity XML·조건 원문·파일 경로를 출력하지 않는다. 후속 AI 분석에 사용하려면 출력 내용을 사용자가 먼저 검토해야 하며, SDK가 외부 모델로 자동 전송하지 않는다. 실패 시 `다음 확인`은 확정 원인이 아닌 조사 시작점이다.

Project Test Hook은 실행 중 `BOOGLE_METRICS_PATH`가 가리키는 임시 파일에 metric 배열을 JSON으로 기록할 수 있다. 각 항목에는 `name`(`namespace/name`), 유한 숫자 `value`, `unit`, `definitionVersion`, `aggregation`, `direction`, `threshold`가 필요하다. 예: `{"name":"artifact/bytes_per_frame","value":120,"unit":"B/frame","definitionVersion":"1","aggregation":"single","direction":"lower","threshold":{"kind":"relative_percent","value":25}}`. 조건값은 원문 대신 해시로 봉인된다. `compare`와 `baseline-compare`는 SDK·Adapter·Test Pack 버전, 실행 조건, metric 정의가 같을 때만 임계값을 적용하며, 다르면 `NOT_COMPARABLE`을 출력한다. 비교가 `FAIL` 또는 `NOT_COMPARABLE`이면 종료 코드 1이다.

캡처·영상·산출물·trace가 필요하면 Project Test Hook은 `BOOGLE_ARTIFACTS_DIR`에 파일을 쓴 뒤 `BOOGLE_ARTIFACTS_PATH`에 `{"artifacts":[{"fileName":"capture.png","kind":"capture"}]}` 형식의 JSON을 기록한다. `kind`는 `capture`, `video`, `output`, `trace`만 허용한다. 목록에 없는 파일, 경로를 포함한 이름, 링크, 중복, 잘못된 형식은 `artifact_invalid`로 처리한다. SDK는 승인된 파일을 해시 이름으로 복사·검증하고 원본 파일명·제출 목록은 실행별 임시 폴더와 함께 제거한다. 실패한 테스트가 제출한 evidence도 보존한다. **파일 내용의 비밀값·개인정보를 SDK가 자동 정제하지는 않으므로**, Hook이 안전한 파일만 제출해야 한다. 원시 로그와 Unity 결과 XML은 제출하지 않는다.

기준선은 자동 생성·교체하지 않는다. 사용자가 `baseline-approve`에 `--confirm`과 3~200자의 승인 사유를 직접 입력해야 한다. `PASS`이고 metric이 있는 봉인 실행만 승인 가능하며, 교체 시 조건·metric 정의가 달라졌다면 새 기준선 이름을 사용해야 한다. 승인 이력은 `projects/<projectId>/baselines/<baselineId>/`에 순번별로 보존된다. 승인 사유에 비밀값·개인정보를 넣지 말아야 하며 명백한 키·이메일 형식은 거부한다.

`cleanup`은 기본적으로 삭제 후보의 실행 ID·상대 경로·크기만 보여준다. `--confirm`을 명시한 경우에만 만료된 `capture`·`video`·`output`·`trace` 파일을 개별 삭제한다. `PASS`는 14일, `FAIL`·`FLAKY`·`MANUAL_REVIEW_REQUIRED`는 90일 이후가 대상이다. 다른 상태와 승인 기준선의 모든 이력·사용자가 `pin`한 실행은 자동 정리하지 않는다. 이미 정리된 실행은 뒤늦게 `pin`하거나 기준선으로 승인할 수 없다. `unpin`에도 `--confirm`이 필요하다. 실행 manifest·result·metric·artifact index는 유지하고, `retention.json`에 정리 대상으로 기록한 파일의 원래 해시·크기와 정리 시각을 보존해 상세 조회와 재색인이 가능하다. CSV의 `retentionMarkedArtifactCount`는 실제 삭제 수가 아닌 정리 기록의 대상 수다. 파일 삭제는 되돌릴 수 없으므로 미리보기와 로컬 백업을 확인한 후 실행한다.

강제 종료로 남은 임시 실행은 실행 중인 Boogle 프로세스가 없는지 확인한 후 `recover --confirm`으로 `INFRA_ERROR` 실행으로 봉인한다. 불완전하거나 검증에 실패한 임시 근거는 자동 삭제하지 않고 오류를 보고한다.

현재 Node.js 24.11.1의 기본 `node:sqlite`를 사용하며 실행 시 실험적 기능 경고가 출력된다. 실행 조건 값은 봉인 전에 SHA-256 해시로 변환하고, artifact는 콘텐츠 해시 기반 파일명과 크기·해시를 검증한다.

## Unity 테스트 실행

일반 명령 설정과 같은 공통 필드를 사용하되 `adapter`를 `unity`로 지정하고 `command` 대신 `unity` 필드를 둔다.

```json
{
  "protocolVersion": "0.1.0",
  "projectId": "e7a4f8cb-8e19-4e91-91dd-e92e068a8418",
  "adapter": { "id": "unity", "version": "0.1.0" },
  "testPack": { "id": "example", "version": "0.1.0" },
  "unity": {
    "editorPath": "C:\\path\\to\\Unity.exe",
    "projectPath": "C:\\path\\to\\UnityProject",
    "testPlatform": "EditMode",
    "assemblyNames": ["MyProject.Tests"],
    "testFilter": "MyProject.Tests.Smoke",
    "timeoutMs": 300000
  },
  "inputConditions": { "fixture": "example-1" },
  "environmentConditions": { "platform": "windows" }
}
```

`assemblyNames`와 `testFilter`는 생략할 수 있다. `testPlatform`은 `EditMode` 또는 `PlayMode`다. SDK는 `Assets`와 `ProjectSettings/ProjectVersion.txt`를 사전 확인한 뒤 Unity Test Framework를 배치 모드로 실행한다. 원시 XML·에디터 로그는 봉인하지 않고, 결과 파일의 요약 수치만 `result.json`에 기록한다. 현재 conformance 테스트는 모의 Unity 실행으로 검증했으며 실제 Unity Editor smoke는 프로젝트 연결 단계에서 확인해야 한다.
